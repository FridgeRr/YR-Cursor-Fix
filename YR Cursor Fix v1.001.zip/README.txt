hotfix v1.001
    added sleep function to dll execution in order to not interfere with syringe and cause a deadlock
==============================
YURIS REVENGE CURSOR FIX
==============================

-------------------
WHAT DOES IT DO?
-------------------
    This application autoinjects a DLL into your gamemd which applies a cursor fix changing the refresh rate of the cursor from 60fps to 120fps.
This results in noticably smoother gameplay for players who play on a 120hz+ monitor which is very common nowadays.
This also has functionality to reinject to new gamemd processes(for Mental Omega players/Yuri's Revenge mods which use the CNCNET Spawner in order to run).

-------------------
HOW TO INSTALL?
-------------------
    Drag and drop YR Cursor Fix and MouseFix.dll, and ddraw.ini into your YR directory.
 Replace the old ddraw.ini.
open ddraw.ini and set:
width=x
height=y
to the resolution you want, e.g 2560x1440 would have x as 2560, y as 1440
refresh_rate=
to whatever refresh rate your monitor is running
Copy the files within CNC-DDRAW folder to your yr directory\resources, and replace cnc-ddraw.dll.


If an error such as MSVCP140D.dll is missing occurs, install Visual C++ 2015-2022 Redistributable (x86) from microsoft website(should come with a google search)
-------------------
HOW TO USE?
-------------------
    Simply run YR Cursor Fix before you start to play the game. You may need to run it as admin, especially if you have gamemd ran as admin.
Do not try to use this for Rambo/CNCNET ladder! You will most likely be flagged by the anti-cheat if you do.
 I am not responsible for any bans through usage of this application. USE AT YOUR OWN RISK.




Special thanks to Kerbiter for providing me the gamemd idb in order for me to reverse engineer and understand how a fix like this would be implemented, as well as
whichever madman documented that idb so well(Tomsons?).


Fridge